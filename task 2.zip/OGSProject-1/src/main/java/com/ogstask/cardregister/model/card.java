package com.ogstask.cardregister.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name= "card_details")

public class card {
	
	@Id
	@Column(name = "card_acc_no")
	private Integer card_acc_no;
	
	@Column(name = "card_name")
	private String card_name;
	
	@Column(name = "card_exp_date")
	private String card_exp_date;
	
	@Column(name = "card_cvv")
	private String card_cvv;

}
