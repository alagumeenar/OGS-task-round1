package com.ogstask.cardregister.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ogstask.cardregister.model.card;
import com.ogstask.cardregister.repository.cardRepository;



public class cardController {
	@Autowired
	cardRepository cardRepo;
	
	@RequestMapping("/")
	public String index() {
		return "index";
	}
	
	@PostMapping("/products")
	public ResponseEntity<?> createcard(@RequestBody card card1) {
		cardRepo.save(card1);
		return ResponseEntity.ok("Card has been saved!!!");
	}
// @RequestMapping(value="/save", method=RequestMethod.POST)
// public ModelAndView save(@ModelAttribute card card1) {
//	 modelAndView.
// }
	
}
 
//@PostMapping("/products")
//public ResponseEntity<?> createproduct(@RequestBody product product) {
//	productRepo.save(product);
//	return ResponseEntity.ok("Product has been saved!!!");
//}