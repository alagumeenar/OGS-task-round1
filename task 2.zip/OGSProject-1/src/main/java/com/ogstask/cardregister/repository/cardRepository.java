package com.ogstask.cardregister.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ogstask.cardregister.model.card;



public interface cardRepository extends JpaRepository<card, Integer> {
	
	card findByCard_Acc_No(Integer key);

}
