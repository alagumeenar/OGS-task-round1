package com.ogstask.cardregister.service;

import java.util.List;

import com.ogstask.cardregister.model.card;


public interface cardService {
	public boolean saveProduct(card card1);
	public List <card> getCards();

}
