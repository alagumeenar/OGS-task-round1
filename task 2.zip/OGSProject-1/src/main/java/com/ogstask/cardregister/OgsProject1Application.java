package com.ogstask.cardregister;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OgsProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(OgsProject1Application.class, args);
	}

}
